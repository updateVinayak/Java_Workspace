package AbstarctClass;

public abstract class AbstractClass {
	
	public String getName(){
		return "default";
	}
	
	public String getAge(){
		return "3";
	}

}
