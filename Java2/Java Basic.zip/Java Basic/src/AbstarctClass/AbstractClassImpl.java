package AbstarctClass;

public class AbstractClassImpl extends AbstractClass{

	

	
}
