package AbstarctClass;

public class MainClass {

	
	public static void main(String[] args) {
		
		AbstractClass sbc = new AbstractClassImpl();
		;
		System.out.println(sbc.getName());
		
	}
}
