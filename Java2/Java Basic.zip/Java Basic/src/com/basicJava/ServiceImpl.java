package com.basicJava;

public class ServiceImpl implements IService {

	public String getName() {
		
		return "Test";
	}

	public String getAge() {
		// TODO Auto-generated method stub
		return "45";
	}

	public String getAddress() {
		// TODO Auto-generated method stub
		return null;
	}

}
