package com.basicJava;

import java.lang.instrument.Instrumentation;

public interface IService2 extends IService{
	
	String getAddress();

}
