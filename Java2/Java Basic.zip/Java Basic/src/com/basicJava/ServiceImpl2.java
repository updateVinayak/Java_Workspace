package com.basicJava;

public class ServiceImpl2 implements IService {

	public String getName() {
		// TODO Auto-generated method stub
		return "Vinay";
	}

	public String getAge() {
		// TODO Auto-generated method stub
		return "32";
	}

}
