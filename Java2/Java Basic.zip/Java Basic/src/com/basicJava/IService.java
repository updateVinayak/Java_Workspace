package com.basicJava;

public interface IService {
	
	static final String name = "Lalubhai";
	
	String getName();
	
	String getAge();

}
